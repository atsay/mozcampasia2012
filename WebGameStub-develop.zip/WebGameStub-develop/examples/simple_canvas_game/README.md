# How to make a simple HTML5 Canvas game

Build your first HTML5 Canvas game in no time! [Read the whole article here!](http://www.lostdecadegames.com/how-to-make-a-simple-html5-canvas-game/)
