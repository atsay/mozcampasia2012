/*global $:true, casper:true, document:true */
'use strict';

casper.test.comment('Pre-test setup');

// This is required if you use localStorage in your app, otherwise any tests
// that rely on a stock state in your app will fail because stuff is stored
// localStorage.
casper.start('http://localhost:3001/', function () {
    casper.test.info('Clearing out localStorage');

    this.evaluate(function() {
        window.localStorage.clear();
    });
}).run(function () {
    this.test.done();
});
