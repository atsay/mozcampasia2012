/*global casper:true */
'use strict';

casper.test.comment('Front-end tests');

casper.start('http://localhost:3001', function () {
    this.test.assertTitle('sutthisan', 'Homepage has the correct title');

    casper.test.info('Testing main app page.');
})

casper.run(function () {
    this.test.done();
})
