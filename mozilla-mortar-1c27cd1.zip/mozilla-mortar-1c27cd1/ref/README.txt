This directory contains reference builds of all the templates in the 
templates directory for the test script to compare newly generated builds
against.
