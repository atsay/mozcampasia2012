({ 
    appDir: "../www",
    baseUrl: "js/lib",
    dir: "../www-built",
    removeCombined: true,
    paths: {
        "app": "../app"
    },
    modules: [
        { name: "app" }
    ]
})
    
        