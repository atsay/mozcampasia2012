# Face Value #

Currency conversion using actual denominations.

## Build Status ##

Continuous integration tests for Face Value are run on the awesome
[Travis CI](http://travis-ci.org): [![Build Status](https://secure.travis-ci.org/tofumatt/face-value.png?branch=master)](http://travis-ci.org/tofumatt/face-value)

# License #

This program is free software; it is distributed under an [MIT License](http://github.com/tofumatt/face-value/blob/master/LICENSE.txt).

---

Copyright (c) 2012 [Matthew Riley MacPherson](http://lonelyvegan.com) and
[sarah ✈ semark](http://triggersandsparks.com).
